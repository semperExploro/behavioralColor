mindHive (File) is for MAC OS/Linux
mindHive (.exe) is for WINDOWS

please make sure that "words.txt" is in the same folder as MindHive or it won't work!